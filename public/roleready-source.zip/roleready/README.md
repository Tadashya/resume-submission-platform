# RoleReady

A public resume-to-job-description checker. Anyone can upload a PDF, DOCX, or TXT resume, add a job description, and receive an estimated match with strengths, gaps in evidence, and practical improvements. Reports can be downloaded as text. No account is required.

Built with TanStack Start, React, TypeScript, Tailwind CSS, Lucide icons, Netlify Functions, Google Gemini through Netlify AI Gateway, and Mammoth for DOCX extraction.

## Local development

Use Node.js 22.13+ and pnpm. Install dependencies with `pnpm install`, then run `netlify dev --port 8889` against the linked Netlify project. AI inference requires Netlify AI Gateway and an initial production deployment. Production builds are handled by Netlify using `netlify.toml`.

## Behavior and privacy

The app sends supplied documents to the AI provider for analysis but does not persist resumes, job descriptions, or assessment results. Refreshing clears the assessment. No documents are sent to recruiters. PDF content is read by Gemini; DOCX text is extracted server-side. Files are limited to 4 MB. Job descriptions must contain 100–18,000 characters. Results are advisory and are not hiring or eligibility decisions.

The primary website is https://resume-submission-platform.netlify.app.
